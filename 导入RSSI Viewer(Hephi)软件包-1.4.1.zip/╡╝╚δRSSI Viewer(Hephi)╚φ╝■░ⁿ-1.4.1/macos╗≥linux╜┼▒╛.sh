#!/bin/bash
# dirname $0，取得当前执行的脚本文件的父目录
basepath=$(cd `dirname $0`; pwd)

#进入到所在的目录
cd ${basepath}/

# 打印当前路径
currentPath=$(pwd)
echo "当前文件夹路径: $currentPath"

files=`find ./ -name "*.tgz"`
des_dir=$HOME/.nrfconnect-apps/local
echo $files
echo $des_dir
if [ ! $files ]
then
    echo "Package missing!!!"
else
    if [ ! -d $des_dir ]
      then
        echo "Please install nrfconnect-apps first!!!"
    else
        cp -p $files $des_dir
        echo "done."
    fi
fi






